"""
AI Workout Rep Counter with Form Analysis
Uses MediaPipe for pose estimation to count reps and analyze form
"""

import cv2
import mediapipe as mp
import numpy as np
import time
from collections import deque

class WorkoutRepCounter:
    def __init__(self):
        # Initialize MediaPipe Pose
        self.mp_pose = mp.solutions.pose
        self.mp_drawing = mp.solutions.drawing_utils
        self.pose = self.mp_pose.Pose(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        
        # Exercise-specific variables
        self.exercise_type = "squat"  # Default exercise
        self.rep_count = 0
        self.stage = None
        self.form_feedback = []
        
        # Motion tracking
        self.angle_history = deque(maxlen=30)
        self.velocity_threshold = 5
        
        # Form analysis parameters
        self.form_scores = []
        self.bad_form_counter = 0
        
    def calculate_angle(self, a, b, c):
        """Calculate angle between three points"""
        a = np.array(a)
        b = np.array(b)
        c = np.array(c)
        
        radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
        angle = np.abs(radians * 180.0 / np.pi)
        
        if angle > 180.0:
            angle = 360 - angle
            
        return angle
    
    def analyze_squat_form(self, landmarks):
        """Analyze squat form and provide feedback"""
        feedback = []
        form_score = 100
        
        # Get key points
        hip = [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x,
               landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y]
        knee = [landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].y]
        ankle = [landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
        shoulder = [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        
        # Check knee angle
        knee_angle = self.calculate_angle(hip, knee, ankle)
        
        # Check if knees are going past toes
        if knee[0] > ankle[0] + 0.05:
            feedback.append("Knees too far forward!")
            form_score -= 20
        
        # Check back alignment
        back_angle = abs(shoulder[0] - hip[0])
        if back_angle > 0.15:
            feedback.append("Keep back straight!")
            form_score -= 15
        
        # Check depth
        if self.stage == "down" and knee_angle > 100:
            feedback.append("Go deeper!")
            form_score -= 10
        
        return feedback, max(0, form_score)
    
    def analyze_pushup_form(self, landmarks):
        """Analyze push-up form"""
        feedback = []
        form_score = 100
        
        shoulder = [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        elbow = [landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
        wrist = [landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].y]
        hip = [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x,
               landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y]
        
        # Check elbow angle
        elbow_angle = self.calculate_angle(shoulder, elbow, wrist)
        
        # Check body alignment (plank position)
        body_angle = abs(shoulder[1] - hip[1])
        if body_angle > 0.1:
            feedback.append("Keep body straight!")
            form_score -= 20
        
        # Check elbow position
        if abs(elbow[0] - shoulder[0]) > 0.2:
            feedback.append("Elbows too wide!")
            form_score -= 15
        
        return feedback, max(0, form_score)
    
    def analyze_bicep_curl_form(self, landmarks):
        """Analyze bicep curl form"""
        feedback = []
        form_score = 100
        
        shoulder = [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        elbow = [landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
        wrist = [landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].y]
        
        # Check if elbow is moving (should be stationary)
        if abs(elbow[0] - shoulder[0]) > 0.15:
            feedback.append("Keep elbow still!")
            form_score -= 20
        
        return feedback, max(0, form_score)
    
    def count_squat_reps(self, landmarks):
        """Count squat repetitions"""
        hip = [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x,
               landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y]
        knee = [landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].y]
        ankle = [landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
        
        angle = self.calculate_angle(hip, knee, ankle)
        self.angle_history.append(angle)
        
        # Squat down
        if angle < 90 and self.stage != "down":
            self.stage = "down"
        
        # Squat up
        if angle > 160 and self.stage == "down":
            self.stage = "up"
            self.rep_count += 1
            
        return angle
    
    def count_pushup_reps(self, landmarks):
        """Count push-up repetitions"""
        shoulder = [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        elbow = [landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
        wrist = [landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].y]
        
        angle = self.calculate_angle(shoulder, elbow, wrist)
        self.angle_history.append(angle)
        
        # Push-up down
        if angle < 90 and self.stage != "down":
            self.stage = "down"
        
        # Push-up up
        if angle > 160 and self.stage == "down":
            self.stage = "up"
            self.rep_count += 1
            
        return angle
    
    def count_bicep_curl_reps(self, landmarks):
        """Count bicep curl repetitions"""
        shoulder = [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        elbow = [landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
        wrist = [landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                 landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].y]
        
        angle = self.calculate_angle(shoulder, elbow, wrist)
        self.angle_history.append(angle)
        
        # Curl up
        if angle < 40 and self.stage != "up":
            self.stage = "up"
        
        # Curl down
        if angle > 160 and self.stage == "up":
            self.stage = "down"
            self.rep_count += 1
            
        return angle
    
    def process_frame(self, frame):
        """Process video frame and count reps"""
        # Convert to RGB
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False
        
        # Make detection
        results = self.pose.process(image)
        
        # Convert back to BGR
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        
        # Extract landmarks
        try:
            landmarks = results.pose_landmarks.landmark
            
            # Count reps based on exercise type
            if self.exercise_type == "squat":
                angle = self.count_squat_reps(landmarks)
                feedback, form_score = self.analyze_squat_form(landmarks)
            elif self.exercise_type == "pushup":
                angle = self.count_pushup_reps(landmarks)
                feedback, form_score = self.analyze_pushup_form(landmarks)
            elif self.exercise_type == "bicep_curl":
                angle = self.count_bicep_curl_reps(landmarks)
                feedback, form_score = self.analyze_bicep_curl_form(landmarks)
            else:
                angle = 0
                feedback = []
                form_score = 0
            
            self.form_feedback = feedback
            self.form_scores.append(form_score)
            
            # Draw pose landmarks
            self.mp_drawing.draw_landmarks(
                image,
                results.pose_landmarks,
                self.mp_pose.POSE_CONNECTIONS,
                self.mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=2),
                self.mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2)
            )
            
            # Display info on frame
            self.draw_info(image, angle, form_score)
            
        except Exception as e:
            pass
        
        return image
    
    def draw_info(self, image, angle, form_score):
        """Draw information overlay on frame"""
        h, w = image.shape[:2]
        
        # Semi-transparent overlay
        overlay = image.copy()
        cv2.rectangle(overlay, (10, 10), (300, 200), (0, 0, 0), -1)
        image = cv2.addWeighted(overlay, 0.6, image, 0.4, 0)
        
        # Exercise type
        cv2.putText(image, f'Exercise: {self.exercise_type.upper()}', 
                    (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Rep count
        cv2.putText(image, f'Reps: {self.rep_count}', 
                    (20, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        
        # Stage
        cv2.putText(image, f'Stage: {self.stage}', 
                    (20, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Angle
        cv2.putText(image, f'Angle: {int(angle)}', 
                    (20, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Form score
        color = (0, 255, 0) if form_score > 80 else (0, 165, 255) if form_score > 60 else (0, 0, 255)
        cv2.putText(image, f'Form: {int(form_score)}%', 
                    (20, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        
        # Form feedback
        y_offset = 230
        for feedback in self.form_feedback:
            cv2.putText(image, feedback, 
                        (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
            y_offset += 35
        
        # Controls
        cv2.putText(image, 'Controls: S-Squat | P-Pushup | B-Bicep Curl | R-Reset | Q-Quit', 
                    (20, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    def set_exercise(self, exercise):
        """Change exercise type"""
        self.exercise_type = exercise
        self.reset()
    
    def reset(self):
        """Reset counter"""
        self.rep_count = 0
        self.stage = None
        self.form_feedback = []
        self.form_scores = []
        self.angle_history.clear()
    
    def get_statistics(self):
        """Get workout statistics"""
        avg_form = np.mean(self.form_scores) if self.form_scores else 0
        return {
            'total_reps': self.rep_count,
            'average_form_score': avg_form,
            'exercise': self.exercise_type
        }


def main():
    """Main function to run the workout rep counter"""
    print("=" * 50)
    print("AI Workout Rep Counter with Form Analysis")
    print("=" * 50)
    print("\nControls:")
    print("  S - Switch to Squats")
    print("  P - Switch to Push-ups")
    print("  B - Switch to Bicep Curls")
    print("  R - Reset counter")
    print("  Q - Quit")
    print("\nStarting camera...")
    
    # Initialize counter
    counter = WorkoutRepCounter()
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    
    if not cap.isOpened():
        print("Error: Could not open camera")
        return
    
    print("Camera ready! Starting workout tracking...")
    
    while cap.isOpened():
        ret, frame = cap.read()
        
        if not ret:
            print("Error: Could not read frame")
            break
        
        # Process frame
        frame = counter.process_frame(frame)
        
        # Display
        cv2.imshow('AI Workout Rep Counter', frame)
        
        # Handle keyboard input
        key = cv2.waitKey(10) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('s'):
            counter.set_exercise('squat')
            print("Switched to Squats")
        elif key == ord('p'):
            counter.set_exercise('pushup')
            print("Switched to Push-ups")
        elif key == ord('b'):
            counter.set_exercise('bicep_curl')
            print("Switched to Bicep Curls")
        elif key == ord('r'):
            counter.reset()
            print("Counter reset")
    
    # Print statistics
    stats = counter.get_statistics()
    print("\n" + "=" * 50)
    print("Workout Summary")
    print("=" * 50)
    print(f"Exercise: {stats['exercise'].upper()}")
    print(f"Total Reps: {stats['total_reps']}")
    print(f"Average Form Score: {stats['average_form_score']:.1f}%")
    print("=" * 50)
    
    # Cleanup
    cap.release()
    cv2.destroyAllWindows()
    counter.pose.close()


if __name__ == "__main__":
    main()
